import cv2
import numpy as np
import mediapipe as mp
import os 
from tensorflow.keras.models import load_model

# Load the trained model
model = load_model('model/asl_model.h5')
classes = sorted(os.listdir("dataset"))  # A-Z based on folder names
img_size = 64

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False,
                       max_num_hands=1,
                       min_detection_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils

# Start webcam
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    roi = frame[100:300, 100:300]

    rgb = cv2.cvtColor(roi, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb)

    if result.multi_hand_landmarks:
        # Optional: draw landmarks
        for hand_landmarks in result.multi_hand_landmarks:
            mp_drawing.draw_landmarks(roi, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        # Preprocess ROI
        roi_resized = cv2.resize(roi, (img_size, img_size))
        roi_normalized = roi_resized / 255.0
        reshaped_roi = roi_normalized.reshape(1, img_size, img_size, 3)
        
        # Predict
        prediction = model.predict(reshaped_roi)
        predicted_class = np.argmax(prediction)
        predicted_label = classes[predicted_class]

        # Display result
        cv2.putText(frame, f'Prediction: {predicted_label}', (50, 70),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 2)

    # Draw ROI rectangle
    cv2.rectangle(frame, (100, 100), (300, 300), (255, 0, 0), 2)

    # Show frame
    cv2.imshow("Sign Language Recognition", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
