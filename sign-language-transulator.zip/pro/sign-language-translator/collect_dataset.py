import cv2
import os

# Change this to the letter you're collecting (A, B, C, ...)
label = 'A'
save_dir = f'dataset/{label}'

os.makedirs(save_dir, exist_ok=True)

cap = cv2.VideoCapture(0)
count = 0

while True:
    ret, frame = cap.read()
    frame = cv2.flip(frame, 1)

    # Draw rectangle for ROI
    cv2.rectangle(frame, (100, 100), (300, 300), (0, 255, 0), 2)
    roi = frame[100:300, 100:300]

    if count < 500:
        filename = os.path.join(save_dir, f'{count}.jpg')
        cv2.imwrite(filename, roi)
        count += 1

    cv2.putText(frame, f'Collected: {count}', (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow("Collecting", frame)

    if cv2.waitKey(1) & 0xFF == ord('q') or count == 500:
        break

cap.release()
cv2.destroyAllWindows()
