import os
import shutil

dataset_path = "dataset"

# Loop through all files in the dataset folder
for filename in os.listdir(dataset_path):
    file_path = os.path.join(dataset_path, filename)

    # Skip if it's already a folder
    if os.path.isdir(file_path):
        continue

    # Extract the first character (e.g. A from A_001.jpg)
    if filename.endswith(('.jpg', '.png', '.jpeg')) and len(filename) > 1:
        label = filename[0].upper()

        # Create target folder if it doesn't exist
        target_folder = os.path.join(dataset_path, label)
        os.makedirs(target_folder, exist_ok=True)

        # Move the file
        shutil.move(file_path, os.path.join(target_folder, filename))

print("✅ Dataset organized into folders A-Z.")
